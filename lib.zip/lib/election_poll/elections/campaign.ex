defmodule ElectionPoll.Elections.Campaign do
  use Ecto.Schema
  import Ecto.Changeset

  schema "campaigns" do
    field :name, :string
    field :slug, :string
    field :secret_code, :string
    field :is_active, :boolean, default: false
    field :starts_at, :utc_datetime
    field :ends_at, :utc_datetime
    field :user_id, :id

    belongs_to :constituency, ElectionPoll.Elections.Constituency

    timestamps(type: :utc_datetime)
  end

  @doc false
  def changeset(campaign, attrs, user_scope) do
    campaign
    |> cast(attrs, [
      :name,
      :slug,
      :secret_code,
      :is_active,
      :starts_at,
      :ends_at,
      :constituency_id
    ])
    |> validate_required([
      :name,
      :slug,
      :secret_code,
      :is_active,
      :starts_at,
      :ends_at,
      :constituency_id
    ])
    |> put_change(:user_id, user_scope.user.id)
  end
end
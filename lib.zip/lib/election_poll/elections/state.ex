defmodule ElectionPoll.Elections.State do
  use Ecto.Schema
  import Ecto.Changeset

  schema "states" do
    field :name, :string
    field :code, :string
    field :display_order, :integer
    field :is_active, :boolean, default: false
    field :user_id, :id

    timestamps(type: :utc_datetime)
  end

  @doc false
  def changeset(state, attrs) do
    state
    |> cast(attrs, [:name, :code, :display_order, :is_active, :user_id])
    |> validate_required([:name, :code, :display_order, :is_active])
  end

  @doc false
  def changeset(state, attrs, user_scope) do
    state
    |> changeset(attrs)
    |> put_change(:user_id, user_scope.user.id)
  end
end
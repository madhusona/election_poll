defmodule ElectionPollWeb.ResponseController do
  use ElectionPollWeb, :controller

  import Ecto.Query

  alias ElectionPoll.Repo
  alias ElectionPoll.Polling.Response
  alias ElectionPoll.Elections.{Campaign, Candidate, Constituency}

  def index(conn, params) do
    scope = conn.assigns.current_scope
    user_id = scope.user.id

    page =
      params
      |> Map.get("page", "1")
      |> parse_int(1)
      |> max(1)

    page_size =
      params
      |> Map.get("page_size", "50")
      |> parse_int(50)
      |> normalize_page_size()

    filters = %{
      constituency_id: blank_to_nil(params["constituency_id"]),
      booth_name: blank_to_nil(params["booth_name"]),
      party: blank_to_nil(params["party"]),
      age_group: blank_to_nil(params["age_group"]),
      gender: blank_to_nil(params["gender"])
    }

    base_query =
      from r in Response,
        join: cam in Campaign, on: cam.id == r.campaign_id,
        join: c in Candidate, on: c.id == r.candidate_id,
        join: con in Constituency, on: con.id == r.constituency_id,
        where: cam.user_id == ^user_id,
        select: %{
          id: r.id,
          submitted_at: r.submitted_at,
          gender: r.gender,
          age_group: r.age_group,
          booth_name: r.booth_name,
          latitude: r.latitude,
          longitude: r.longitude,
          selfie_path: r.selfie_path,
          constituency_name: con.name,
          constituency_id: con.id,
          candidate_name: c.candidate_name,
          party_full_name: c.party_full_name,
          campaign_id: cam.id,
          campaign_name: cam.name
        }

    filtered_query = apply_filters(base_query, filters)

    total_count =
      filtered_query
      |> exclude(:preload)
      |> exclude(:order_by)
      |> subquery()
      |> Repo.aggregate(:count, :id)

    total_pages =
        case total_count do
            0 -> 1
            _ -> div(total_count + page_size - 1, page_size)
        end

    page = min(page, total_pages)
    offset = (page - 1) * page_size

    responses =
      filtered_query
      |> order_by([r], desc: r.submitted_at, desc: r.id)
      |> limit(^page_size)
      |> offset(^offset)
      |> Repo.all()

    constituencies =
      from(con in Constituency,
        join: cam in Campaign, on: cam.constituency_id == con.id,
        where: cam.user_id == ^user_id,
        distinct: con.id,
        order_by: con.name,
        select: %{id: con.id, name: con.name}
      )
      |> Repo.all()

    booths =
      from(r in Response,
        join: cam in Campaign, on: cam.id == r.campaign_id,
        where:
          cam.user_id == ^user_id and
          not is_nil(r.booth_name) and
          r.booth_name != "",
        distinct: r.booth_name,
        order_by: r.booth_name,
        select: r.booth_name
      )
      |> Repo.all()

    parties =
        from(r in Response,
            join: cam in Campaign, on: cam.id == r.campaign_id,
            join: c in Candidate, on: c.id == r.candidate_id,
            where:
            cam.user_id == ^user_id and
            not is_nil(c.party_full_name) and
            c.party_full_name != "",
            distinct: c.party_full_name,
            order_by: c.party_full_name,
            select: c.party_full_name
        )
        |> Repo.all()

    render(conn, :index,
      responses: responses,
      filters: filters,
      constituencies: constituencies,
      booths: booths,
      parties: parties,
      page: page,
      page_size: page_size,
      total_count: total_count,
      total_pages: total_pages
    )
  end

  def export_csv(conn, params) do
    scope = conn.assigns.current_scope
    user_id = scope.user.id

    filters = %{
        constituency_id: blank_to_nil(params["constituency_id"]),
        booth_name: blank_to_nil(params["booth_name"]),
        party: blank_to_nil(params["party"]),
        age_group: blank_to_nil(params["age_group"]),
        gender: blank_to_nil(params["gender"])
    }

    query =
        from r in Response,
        join: cam in Campaign, on: cam.id == r.campaign_id,
        join: c in Candidate, on: c.id == r.candidate_id,
        join: con in Constituency, on: con.id == r.constituency_id,
        where: cam.user_id == ^user_id,
        select: %{
            id: r.id,
            submitted_at: r.submitted_at,
            constituency_name: con.name,
            booth_name: r.booth_name,
            candidate_name: c.candidate_name,
            party_full_name: c.party_full_name,
            gender: r.gender,
            age_group: r.age_group,
            latitude: r.latitude,
            longitude: r.longitude,
            selfie_path: r.selfie_path,
            campaign_name: cam.name
        }

    rows =
        query
        |> apply_filters(filters)
        |> order_by([r], desc: r.submitted_at, desc: r.id)
        |> Repo.all()

    csv_data =
        [
        [
            "ID",
            "Submitted At",
            "Campaign",
            "Constituency",
            "Booth",
            "Candidate",
            "Party",
            "Gender",
            "Age Group",
            "Latitude",
            "Longitude",
            "Selfie Path"
        ]
        | Enum.map(rows, fn row ->
            [
                row.id,
                format_csv_value(row.submitted_at),
                row.campaign_name,
                row.constituency_name,
                row.booth_name,
                row.candidate_name,
                row.party_full_name,
                row.gender,
                row.age_group,
                row.latitude,
                row.longitude,
                row.selfie_path
            ]
            end)
        ]
        |> Enum.map(&csv_line/1)
        |> Enum.join("")

    filename = "responses_export_#{Date.utc_today()}.csv"

    conn
    |> put_resp_content_type("text/csv")
    |> put_resp_header("content-disposition", ~s(attachment; filename="#{filename}"))
    |> send_resp(200, csv_data)
    end

    defp csv_line(fields) do
    fields
    |> Enum.map(&escape_csv_field/1)
    |> Enum.join(",")
    |> Kernel.<>("\n")
    end

    defp escape_csv_field(nil), do: "\"\""

    defp escape_csv_field(value) do
    value =
        case value do
        %NaiveDateTime{} -> NaiveDateTime.to_string(value)
        %DateTime{} -> DateTime.to_string(value)
        _ -> to_string(value)
        end

    "\"" <> String.replace(value, "\"", "\"\"") <> "\""
    end

    defp format_csv_value(nil), do: ""
    defp format_csv_value(%NaiveDateTime{} = dt), do: NaiveDateTime.to_string(dt)
    defp format_csv_value(%DateTime{} = dt), do: DateTime.to_string(dt)
    defp format_csv_value(value), do: to_string(value)

  defp apply_filters(query, filters) do
    query
    |> maybe_filter_constituency(filters.constituency_id)
    |> maybe_filter_booth(filters.booth_name)
    |> maybe_filter_party(filters.party)
    |> maybe_filter_age(filters.age_group)
    |> maybe_filter_gender(filters.gender)
  end

  defp maybe_filter_constituency(query, nil), do: query
  defp maybe_filter_constituency(query, constituency_id) do
    where(query, [r], r.constituency_id == ^parse_int(constituency_id, 0))
  end

  defp maybe_filter_booth(query, nil), do: query
  defp maybe_filter_booth(query, booth_name) do
    where(query, [r], r.booth_name == ^booth_name)
  end

  defp maybe_filter_party(query, nil), do: query
  defp maybe_filter_party(query, party) do
    where(query, [_r, _cam, c], c.party_full_name == ^party)
  end

  defp maybe_filter_age(query, nil), do: query
  defp maybe_filter_age(query, age_group) do
    where(query, [r], r.age_group == ^age_group)
  end

  defp maybe_filter_gender(query, nil), do: query
  defp maybe_filter_gender(query, gender) do
    where(query, [r], r.gender == ^gender)
  end

  defp parse_int(nil, default), do: default
  defp parse_int(value, default) when is_integer(value), do: value
  defp parse_int(value, default) when is_binary(value) do
    case Integer.parse(value) do
      {int, _} -> int
      :error -> default
    end
  end

  defp normalize_page_size(size) when size in [50, 100], do: size
  defp normalize_page_size(_), do: 50

  defp blank_to_nil(nil), do: nil
  defp blank_to_nil(""), do: nil
  defp blank_to_nil(value), do: value
end
defmodule ElectionPollWeb.ResponseHTML do
  use ElectionPollWeb, :html

  embed_templates "response_html/*"
end
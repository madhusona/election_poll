defmodule ElectionPollWeb.SecureUploadController do
  use ElectionPollWeb, :controller

  def show_selfie(conn, %{"filename" => filename}) do
    if invalid_filename?(filename) do
      send_resp(conn, 400, "Invalid filename")
    else
      path =
        Path.join([
          :code.priv_dir(:election_poll),
          "static",
          "uploads",
          "selfies",
          filename
        ])

      if File.exists?(path) do
        conn
        |> put_resp_header("cache-control", "private, max-age=3600")
        |> send_file(200, path)
      else
        send_resp(conn, 404, "File not found")
      end
    end
  end

  defp invalid_filename?(filename) do
    filename != Path.basename(filename) or
      String.contains?(filename, ["..", "/", "\\"])
  end
end